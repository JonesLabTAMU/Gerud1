GERUD1.0 and GERUDsim1.0 - programs for the reconstruction of parental genotypes 
from progeny arrays

Adam G. Jones
email: jonesa@bcc.orst.edu

The GERUD package is made up of several files.  GERUD1.exe and GERUDsim1.exe are 
the program files.  Simply double click on the icon to run the program.  Two 
additional files, borlndmm.dll and cc3250mt.dll, are necessary for the GERUD 
programs to run.  These files should be in the same folder as GERUD1.exe and 
GERUDsim1.exe.

The Microsoft Word file, GERUDmanual.doc, describes the use of GERUD1.0 and 
GERUDsim1.0.  Two sample progeny array files, FCST9progeny.txt and 
FCST11progeny.txt, are included.  These are suitable for analysis using 
GERUD1.0.  TyphAlleleFrequencies.txt is a sample allele frequency file of the 
type used by both GERUD1.0 and GERUDsim1.0.

GERUD1.0 and GERUDsim1.0 are the first release versions of these programs.  
While I have tested the programs fairly extensively, they may still contain 
bugs.  If any unusual behavior is noted from either program, please contact me 
by email.
